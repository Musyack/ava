const ApiError = require('../error/ApiError')
const {Order, User} = require('../models/models')
class OrderController {
    async create (req, res, next) {
        const {link, quantity, time} = req.body
        if (!link || !quantity || !time){
            return next()
        }
        const candidate = await Order.findOne({where: {link}})
        if (candidate) {
            return next(ApiError.badRequest('Заказ с такой ссылкой уже существует'))
        }
        const order = await Order.create({link, time, quantity})
        return res.json({order})
    }
}

module.exports = new OrderController()