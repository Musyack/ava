const Router = require('express')
const router = new Router()
const userRouter = require('../routes/userRouter')
const orderRouter = require('../routes/orderRouter')

router.use('/user', userRouter)
router.use('/order', orderRouter)

module.exports = router
